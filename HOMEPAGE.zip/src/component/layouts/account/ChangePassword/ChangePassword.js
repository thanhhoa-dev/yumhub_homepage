function ChangePassword() {
    return ( 
        <div>
            <h1>ChangePassword Page</h1>
        </div>
     );
}

export default ChangePassword;